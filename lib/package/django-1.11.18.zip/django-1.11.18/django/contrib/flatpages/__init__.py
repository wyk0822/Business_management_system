default_app_config = 'django.contrib.flatpages.apps.FlatPagesConfig'
